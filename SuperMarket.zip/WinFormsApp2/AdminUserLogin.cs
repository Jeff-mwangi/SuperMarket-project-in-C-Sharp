﻿using SuperMarket;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sellers
{
    public partial class AdminUserLogin : Form
    {
        public AdminUserLogin()
        {
            InitializeComponent();
        }

        private void maskedTextBox3_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {  
            if(LoginUsername.Text =="" || LoginPass.Text=="")
            {
                MessageBox.Show("Enter UserName and Password");
            }
            else 
            {
                if (SelectRole.SelectedIndex > -1) 
                {
                if (SelectRole.SelectedItem.ToString()=="ADMIN")
                {
                    if(LoginUsername.Text =="me" && LoginPass.Text=="me")
                    {
                        ProductForm prod = new ProductForm();
                        prod.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("If you are an Admin, Enter the correct Username and Password");
                    }
                }
                else if (SelectRole.SelectedItem.ToString() == "SELLER")
                    {
                        SellingPage sl = new SellingPage();
                        sl.Show();
                        this.Hide();
                    }
                }
                else
                {
                    MessageBox.Show("Select a Role");
                }
            }
           

        }

        private void label4_Click(object sender, EventArgs e)
        {
            LoginUsername.Text = "";
            LoginPass.Text = "";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (Passcheck.Checked)
            {
                LoginPass.UseSystemPasswordChar = false;
            }
            else
            {
                LoginPass.UseSystemPasswordChar = true;
            }
        }

        private void LoginUsername_TextChanged(object sender, EventArgs e)
        {
            label4.Enabled = LoginUsername.Text != "" || LoginPass.Text != "" ? true : false;
            button1.Enabled = LoginUsername.Text != "" && LoginPass.Text != "" ? true : false;

        }
    }
}
