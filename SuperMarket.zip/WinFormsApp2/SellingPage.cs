﻿using System;
using Sellers;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SuperMarket
{
    public partial class SellingPage : Form
    {
        public SellingPage()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\moses\source\repos\WinFormsApp2\SuperMarketDb.mdf;Integrated Security=True");
        public void populate()
        {
            string query = "select ProductName,ProductPrice from ProdTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            SellingDatagrid.DataSource = ds.Tables[0];
            
        }

        private void SellingPage_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void SellingDatagrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ProductName.Text = SellingDatagrid.SelectedRows[0].Cells[0].Value.ToString();
            ProductPrice.Text = SellingDatagrid.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            DateLabel.Text = DateTime.Today.Day.ToString() + "/" + DateTime.Today.Month.ToString() + "/" + DateTime.Today.Year.ToString();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void DateLabel_Click(object sender, EventArgs e)
        {
        }

        private void label6_Click(object sender, EventArgs e)
        {
            DataGridView newRow = new DataGridView();
        }

        private void OrderGDV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            AdminUserLogin adminUser = new AdminUserLogin();
            adminUser.Show();
            this.Hide();

        }
    }
}
