﻿using System;
using SuperMarket;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Sellers;

namespace SuperMarket
{
    public partial class WelcomeForm : Form
    {
        public WelcomeForm()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            panel5.Width += 3;
            if (panel5.Width >= 608)
            {
                timer1.Stop();
                AdminUserLogin admin = new AdminUserLogin();
                admin.Show();
                this.Hide();
            }
        }
    }
}
