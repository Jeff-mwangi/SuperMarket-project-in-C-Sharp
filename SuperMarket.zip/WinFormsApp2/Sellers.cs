﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Sellers
{
    public partial class Sellers : Form
    {
        public Sellers()
        {
            InitializeComponent();
        }
        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\moses\source\repos\WinFormsApp2\SuperMarketDb.mdf;Integrated Security=True");
        private void add_Click(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                string query = "insert into sellers values(" + SellerId.Text+",'"+SellerName.Text+"','"+SellerPhone.Text+"','"+SellerPass.Text+"', '"+gender+"')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("User added Successfully");
                Con.Close();
                populateForm();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void populate()
        {
            Con.Open();
            string query = "select * from sellers";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            SellerDisplay.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void Sellers_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void SellerDisplay_CellContentClick(object sender, DataGridViewCellEventArgs e)
        { 
            SellerId.Text = SellerDisplay.SelectedRows[0].Cells[0].Value.ToString();
            SellerName.Text = SellerDisplay.SelectedRows[0].Cells[1].Value.ToString();
            SellerPhone.Text = SellerDisplay.SelectedRows[0].Cells[2].Value.ToString();
            SellerPass.Text = SellerDisplay.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            try
            {
                if(SellerId.Text == "")
                {
                    MessageBox.Show("Select a Row to Delete");
                }
                else
                {
                    Con.Open();
                    string query = "delete from sellers where SellerId = " + SellerId.Text + "";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Deleted Successfully");
                    Con.Close();
                    populateForm();

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void label11_Click(object sender, EventArgs e)
        {
            try
            {
                if (SellerId.Text == "" || SellerName.Text == "" || SellerPhone.Text == "" || SellerPass.Text == "")
                {
                    MessageBox.Show("Missing Some Information");
                }
                else
                {
                    Con.Open();
                    string query = "update sellers set SellerName = '" + SellerName.Text + "', SellerPhone = '" + SellerPhone.Text + "', SellerPass = '" + SellerPass.Text + "' where SellerId = '" + SellerId.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("The Information was Updated Successfully!");
                    Con.Close();
                    populateForm();
                }
            }
            catch(Exception ex)
             {
                MessageBox.Show(ex.Message);
            }
        }
        public void populateForm()
        {
            Con.Open();
            string query = "select * from sellers";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            SellerDisplay.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void showPass_CheckedChanged(object sender, EventArgs e)
        {
            if(showPass.Checked)
            {
                SellerPass.UseSystemPasswordChar = false;
            }
            else
            {
                SellerPass.UseSystemPasswordChar = true;
            }
        }

        private void SellerPass_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {
            populateForm();
        }
        string gender;
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

