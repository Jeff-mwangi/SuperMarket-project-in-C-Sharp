﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using WinFormsApp2;
using SuperMarket;
using Sellers;

namespace SuperMarket
{
    public partial class ProductForm : Form
    {
        public ProductForm()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Con.Open();
            string query = "update ProdTable set ProductName='" + ProductName.Text + "', ProductQtty='" + ProductQtty.Text + "', ProductPrice='" + ProductPrice.Text + "' where  ProductId='" + ProductId.Text + "' ";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Information Updated Successfully");
            populate();
            Con.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\moses\source\repos\WinFormsApp2\SuperMarketDb.mdf;Integrated Security=True");
        private void add_Click(object sender, EventArgs e)
        {
            try
            {
            Con.Open();
            string query = "insert into ProdTable values('" + ProductId.Text + "', '" + ProductName.Text + "', '" + ProductQtty.Text + "', '" + ProductPrice.Text + "')";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("User Added SuccessFully");
            populate();
            Con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        public void populate()
        {
            string query = "select * from ProdTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ProductDisplay.DataSource = ds.Tables[0];
        }
        private void ProductForm_Load(object sender, EventArgs e)
        {
            populate();
            fillCombo();
            CategorySelect();
        }
        public void CategorySelect()
        {
            Con.Open();
            string query = "select CatName from CategoryTable";
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CatName", typeof(string));
            dt.Load(rdr);
            CatSelect.ValueMember = "CatName";
            CatSelect.DataSource = dt;
            Con.Close();

        }

        private void ProductDisplay_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ProductId.Text = ProductDisplay.SelectedRows[0].Cells[0].Value.ToString();
            ProductName.Text = ProductDisplay.SelectedRows[0].Cells[1].Value.ToString();
            ProductQtty.Text = ProductDisplay.SelectedRows[0].Cells[2].Value.ToString();
            ProductPrice.Text = ProductDisplay.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            try
            {
                if (ProductId.Text == "")
                {
                    MessageBox.Show("Select a Row to delete");
                }
                else
                {
                    Con.Open();
                    string query = "delete from ProdTable where ProductId='" + ProductId.Text + "' ";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Information Deleted Successfully");
                    populate();
                    Con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            CategoryForm cat = new CategoryForm();
            cat.Show();
            this.Hide();
        }
        private void fillCombo()
        {
            Con.Open();
            string query = "select CatName from CategoryTable";
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CatName", typeof(string));
            dt.Load(rdr);
            CatSelect.ValueMember = "CatName";
            CatSelect.DataSource = dt;
            Con.Close();
        }

        private void label14_Click(object sender, EventArgs e)
        {
            SellingPage Sp = new SellingPage();
            Sp.Show();
            this.Hide();

        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void label7_Click(object sender, EventArgs e)
        {
            AdminUserLogin admin = new AdminUserLogin();
            admin.Show();
            this.Hide();
        }
    }
}
